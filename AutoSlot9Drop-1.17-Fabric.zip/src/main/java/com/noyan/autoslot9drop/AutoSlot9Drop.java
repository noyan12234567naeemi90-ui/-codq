package com.noyan.autoslot9drop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.nbt.NbtCompound;

public class AutoSlot9Drop implements ClientModInitializer {
    // PlayerInventory index 8 is the ninth hotbar slot.
    private ItemStack previous = ItemStack.EMPTY;
    private boolean dropQueued = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;

        if (player == null || client.interactionManager == null) {
            previous = ItemStack.EMPTY;
            dropQueued = false;
            return;
        }

        ItemStack current = player.getInventory().getStack(8);

        // Detect a newly arriving stack in hotbar slot 9.
        if (previous.isEmpty() && !current.isEmpty()) {
            dropQueued = true;
        }

        if (dropQueued && !current.isEmpty() && player.currentScreenHandler != null) {
            // Player inventory hotbar slots are numbered 36..44 in the player handler.
            client.interactionManager.clickSlot(
                player.currentScreenHandler.syncId,
                44,
                1,
                SlotActionType.THROW,
                player
            );
            dropQueued = false;
            previous = ItemStack.EMPTY;
            return;
        }

        previous = current.copy();
    }
}
